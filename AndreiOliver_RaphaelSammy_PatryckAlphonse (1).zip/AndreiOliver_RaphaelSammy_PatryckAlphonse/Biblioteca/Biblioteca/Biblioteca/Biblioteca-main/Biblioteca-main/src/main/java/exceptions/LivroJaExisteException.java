package exceptions;

public class LivroJaExisteException extends Exception {
    public LivroJaExisteException(String msg){
        super(msg);
    }
}
